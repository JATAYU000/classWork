import java.util.*;
public class Teacher{
	private String name;
	private int age;
	private String course;
	public Teacher(String name,int age,String course){
		this.name = name;
		this.age = age;
		this.course = course;
	}
	public String getname(){return this.name;}
	public int getage(){return this.age;}
	public String getcourse(){return this.course;}
	
	public void setCourse(String course){
	  this.course = course;
	}
	
	public void display(){
	  System.out.println("name: " + this.getname());
		System.out.println("age: " + this.getage());
		System.out.println("course: "+this.getcourse());
	}
	
	public static void main(String[] args){
		Teacher t1 = new Teacher("Ragav",20,"java");
		Teacher t2 = new Teacher("Tina",30,"maths");
		Teacher t3 = new Teacher("ram",25,"java");
		
		t2.display();
		t2.setCourse("java");
		t2.display();
		
		}

}
