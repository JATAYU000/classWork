public class DisplayMethod {
    
    // Method to display arguments of different types
    public static void display(String arg1, int arg2) {
        System.out.println("Arguments: " + arg1 + ", " + arg2);
    }

    public static void display(int arg1, String arg2) {
        System.out.println("Arguments: " + arg1 + ", " + arg2);
    }

    public static void main(String[] args) {
        // Pass arguments String first and Integer second
        display("Hello", 42);

        // Pass arguments Integer first and String second
        display(99, "World");
    }
}
