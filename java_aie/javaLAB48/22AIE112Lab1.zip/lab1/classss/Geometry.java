public abstract class Geometry{
    void setDimension(){}
    void display(){}
    abstract void getArea();

    
}