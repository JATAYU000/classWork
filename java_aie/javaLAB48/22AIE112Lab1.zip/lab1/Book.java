public class Book {
    private String title;
    private String author;
    private String ISBN;

    // Constructor
    public Book(String title, String author, String ISBN) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
    }

    // Method to display details
    public void displayDetails() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("ISBN: " + ISBN);
        System.out.println();
    }

    // Methods to update title, author, and ISBN
    public void updateTitle(String newTitle) {
        this.title = newTitle;
    }

    public void updateAuthor(String newAuthor) {
        this.author = newAuthor;
    }

    public void updateISBN(String newISBN) {
        this.ISBN = newISBN;
    }

    public static void main(String[] args) {
        // Create two instances of Book
        Book book1 = new Book("BOOK1", "ABC", "876523");
        Book book2 = new Book("BOOK2", "DEF", "978543");

        // Display details
        System.out.println("Details of Book 1:");
        book1.displayDetails();

        System.out.println("Details of Book 2:");
        book2.displayDetails();

        // Update BOOK1 → BOOK3
        book1.updateTitle("BOOK3");

        // Create a new instance of Book (BOOK1, GHI, 765498)
        Book book3 = new Book("BOOK1", "GHI", "765498");

        // Display details of updated and new books
        System.out.println("Details of Updated Book 1 (BOOK3):");
        book1.displayDetails();

        System.out.println("Details of New Book 3:");
        book3.displayDetails();
    }
}
