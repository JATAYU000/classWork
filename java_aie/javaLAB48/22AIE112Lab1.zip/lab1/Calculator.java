import java.util.*;
class Calculator{
	public static void main(String[] args){
		Scanner obj = new Scanner(System.in);
		int a = 1;
		while(a==1){
		System.out.println("\n------CALCULATOR------\n1.add\n2.sub\n3.multiply\n4.divide");
		int choice = obj.nextInt();
		System.out.println("Enter the first operand");
		double num1 = obj.nextDouble();
		System.out.println("Enter the second operand");
		double num2 = obj.nextDouble();
		switch(choice){
			case 1: System.out.println(num1+" + "+num2+" = "+(num1+num2));
			break;
			case 2: System.out.println(num1+" - "+num2+" = "+(num1-num2));
			break;
			case 3: System.out.println(num1+" x "+num2+" = "+(num1*num2));
			break;
			case 4: {
			if(num2!=0.0){
				System.out.println(num1+" / "+num2+" = "+(num1/num2));
			} else {
				System.out.println("Cannot divide by 0");
			}
			break;}
			default:System.out.println("Exiting code..");
		}
		System.out.println("\nDo you wish to continue(1/0)");
		a = obj.nextInt();
		}
	}
}

