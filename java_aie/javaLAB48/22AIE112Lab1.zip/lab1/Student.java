import java.util.*;
public class Student{
	private String name;
	private String grade;
	private ArrayList<String> course = new ArrayList<String>();
	public Student(String name,String grade,ArrayList<String> course){
		this.name = name;
		this.grade = grade;
		this.course = course;
	}
	public String getname(){return this.name;}
	public String getgrade(){return this.grade;}
	public ArrayList<String> getcourse(){return this.course;}
	
	public void addCourse(String c){
	  this.course.add(c);
	}
	public void remCourse(int c){
	  this.course.remove(c);
	}
	
	public void display(){
	  System.out.println("name: " + this.getname());
		System.out.println("grade: " + this.getgrade());
		System.out.println("courses: "+this.getcourse());
	}
	
	public static void main(String[] args){
	  Scanner obj = new Scanner(System.in);
	  System.out.println("Enter name:");
    String name = obj.next();
    System.out.println("Enter grade:");
    String grade = obj.next();
    System.out.println("Enter num  of course:");
    int courseno = obj.nextInt();
    ArrayList<String> courses = new ArrayList<String>();
    
    for(int i=1;i<=courseno;i++){
    System.out.println("\tEnter Course name:");
      courses.add(obj.next());
    }
    Student s1 = new Student(name,grade,courses);
    
    
    System.out.println("Enter name:");
    name = obj.next();
    System.out.println("Enter grade:");
    grade = obj.next();
    System.out.println("Enter num  of course:");
    courseno = obj.nextInt();
    courses.removeAll(courses);
    
    for(int i=1;i<=courseno;i++){
    System.out.println("\tEnter Course name:");
      courses.add(obj.next());
    }

		Student s2 = new Student(name,grade,courses);
		s1.display();
		s2.display();
		s2.addCourse("java");
		s1.remCourse(0);
		s1.display();
		s2.display();
		
		}

}
