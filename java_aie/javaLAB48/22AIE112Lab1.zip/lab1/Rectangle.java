import java.util.*;
public class Rectangle{
	private double length;
	private double breadth;
	public Rectangle(double length,double breadth){
		this.length = length;
		this.breadth = breadth;
	}
	
	public double area(){
		return this.length*this.breadth;
	}
	public double peri(){
		return 2*(this.length+this.breadth);
	}
	
	public double getlen(){
	  return this.length;
	}
	public void setlen(double length){
	  this.length = length;
	}
	public double getbth(){
	  return this.breadth;
	}
	public void setbth(double breadth){
	  this.breadth = breadth;
	}
	public static void main(String[] args){
		Rectangle r1 = new Rectangle(10,20);
		System.out.println("Rectangle 1 before:");
		System.out.println("Length: " + r1.getlen());
		System.out.println("breadth: " + r1.getbth());
		System.out.println("Area: "+r1.area());
		System.out.println("peri: "+r1.peri());
		r1.setlen(20);
		r1.setbth(30);
		System.out.println("Rectangle 1 after:");
		System.out.println("Length: " + r1.getlen());
		System.out.println("breadth: " + r1.getbth());
		System.out.println("Area: "+r1.area());
		System.out.println("peri: "+r1.peri());
		
		}

}
