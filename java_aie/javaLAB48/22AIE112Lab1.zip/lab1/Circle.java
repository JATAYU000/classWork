import java.util.*;
public class Circle{
	private double radius;
	public Circle(double radius){
		this.radius = radius;
	}
	
	double area(){
		return 3.14*this.radius*this.radius;
	}
	double circum(){
		return 6.28*this.radius;
	}
	public static void main(String[] args){
		Circle c1 = new Circle(50);
		Circle c2 = new Circle(5);
		Circle c3 = new Circle(20);
		System.out.println("Circle 1:");
		System.out.println("Area: "+c1.area());
		System.out.println("Circum: "+c1.circum());
		System.out.println("Circle 2:");
		System.out.println("Area: "+c2.area());
		System.out.println("Circum: "+c2.circum());
		System.out.println("Circle 3:");
		System.out.println("Area: "+c3.area());
		System.out.println("Circum: "+c3.circum());
		}

}
