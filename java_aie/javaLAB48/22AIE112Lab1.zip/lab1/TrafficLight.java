public class TrafficLight {

    String colour;
    String duration;

    TrafficLight(String c, String d){
        this.colour = c;
        this.duration = d;

    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    void Check(){
        if(colour == "red"){
            System.out.println("The colour is red");
        }
        else{
            System.out.println("The colour is green");
        }

    }

    public static void main(String[] args) {
        TrafficLight t1 = new TrafficLight("red", "10 minutes");
        t1.setColour("Green");
        t1.Check();

    }





}
