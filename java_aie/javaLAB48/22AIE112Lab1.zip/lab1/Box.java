public class Box{
    int width;
    int height;
    int depth;

    public Box(){}
    
    public Box(int w,int h,int d){
        this.width=w;
        this.height=h;
        this.depth =d;
    }
    public void setDim(int w,int h,int d){
        this.width=w;this.height=h;this.depth=d;
    }

    public int getVol(){
        int vol = this.height*this.width*this.depth;
        System.out.println("Volume from Method: "+vol);
        return vol;
    }

    public static void main(String args[]){
        Box box1 = new Box();
        box1.setDim(100,20,15);
        System.out.println("Volume from Main: "+(box1.width*box1.height*box1.depth));
        Box box2 = new Box(200,30,10);
        int vol2 = box2.getVol();
    }
}