public class Book {
    private String title;
    private String author;
    private String ISBN;

    public Book(String title, String author, String ISBN) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
    }

    public void displayDetails() {
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("ISBN: " + ISBN);
        System.out.println();
    }

    public void updateTitle(String newTitle) {
        this.title = newTitle;
    }

    public void updateAuthor(String newAuthor) {
        this.author = newAuthor;
    }

    public void updateISBN(String newISBN) {
        this.ISBN = newISBN;
    }

    public static void main(String[] args) {
        Book book1 = new Book("BOOK1", "ABC", "876523");
        Book book2 = new Book("BOOK2", "DEF", "978543");

        System.out.println("Details of Book 1:");
        book1.displayDetails();

        System.out.println("Details of Book 2:");
        book2.displayDetails();

        book1.updateTitle("BOOK3");

        Book book3 = new Book("BOOK1", "GHI", "765498");

        System.out.println("Details of Updated Book 1 (BOOK3):");
        book1.displayDetails();

        System.out.println("Details of New Book 3:");
        book3.displayDetails();
    }
}
