import java.util.*;
public class Student{
	private String name;
	private String grade;
	private String course = new String();
	public Student(String name,String grade,String course){
		this.name = name;
		this.grade = grade;
		this.course = course;
	}
	public String getname(){return this.name;}
	public String getgrade(){return this.grade;}
	public String getcourse(){return this.course;}
	
	public void addCourse(String c){
	  this.course = c;
	}
	
	public void display(){
	  System.out.println("name: " + this.getname());
		System.out.println("grade: " + this.getgrade());
		System.out.println("courses: "+this.getcourse());
	}
	
	public static void main(String[] args){
	  Scanner obj = new Scanner(System.in);
	  System.out.println("Enter name:");
    String name = obj.next();
    System.out.println("Enter grade:");
    String grade = obj.next();
    System.out.println("Enter Course name:");
	String courses = obj.next();
    Student s1 = new Student(name,grade,courses);
    
    
    System.out.println("Enter name:");
    name = obj.next();
    System.out.println("Enter grade:");
    grade = obj.next();
    System.out.println("Enter course:");
	courses = obj.next();

		Student s2 = new Student(name,grade,courses);
		s1.display();
		s2.display();
		s2.addCourse("java");
		s1.display();
		s2.display();
		
		}

}
