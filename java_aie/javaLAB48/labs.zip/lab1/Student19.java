public class Student19 {

    String firstname;
    String  lastname;
    int age = 18;
    int rollnumber;
    String branch;
    int year;
    String university = "Amrita Vishwa Vidyapeetham";

Student19(){
    age = 18;
    university = "Amrita Vishwa Vidyapeetham";
}

Student19(String fn, String ln,int rn, String br, int ye){
    firstname = fn;
    lastname = ln;
    rollnumber = rn;
    branch = br;
    year = ye;
}



Student19(String fn, String ln, int a, int rn, String br, int ye, String uni){
    firstname = fn;
    lastname = ln;
    age = a;
    rollnumber = rn;
    branch = br;
    year = ye;
    university = uni;
}

public static void main(String[] args) {
    Student19 s1 = new Student19("Ram", "Shyam",3456, "Maths", 2021);
   System.out.println(s1.age);
    System.out.println(s1.university);
}

}
