public class FacultyEmployee48 extends EmployeePerson48{
    private String officeHours;
    public FacultyEmployee48(String name, int phoneNum, String address, String email, int salary, String department, MyDate48 dateHired, String officeHours){
        super(name, phoneNum, address, email, salary, department, dateHired);
        this.officeHours = officeHours;
    }
    public String getOfficeHours(){
        return this.officeHours;
    }
    public void setOfficeHours(String officeHours){
        this.officeHours = officeHours;
    }
    public String toString(){
       return ("Name: " + super.getName() + "\nisFrom Class: FacultyEmployee");
    }
    public static void main(String[] args){
        MyDate48 date = new MyDate48(2019, 1, 1);
        FacultyEmployee48 fac = new FacultyEmployee48("Joe M", 969420024, "Amritapuri, Kollam", "jmama@gmail.com", 1200000, "CSE", date, "9-5");
         System.out.println(fac.toString());}
}