public class Employee48{
    private int salary;
    public Employee48(int salary){
        this.salary = salary;
    }
    public int getSalary(){
        return this.salary;
    }
    public void work(){
        System.out.println("Employee is working");
    }
}