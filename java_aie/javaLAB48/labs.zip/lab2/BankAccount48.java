public class BankAccount48 {
    private double balance;
    public BankAccount48(double balance){
        this.balance = balance;
    }
    public double getBalance(){
        return this.balance;
    }
    public double deposit(double amount){
        this.balance += amount;
        return this.balance;
    }
    public double withdraw(double amount){
        this.balance -= amount;
        return this.balance;
    }
    public static void main(String[] args){
        BankAccount48 account = new BankAccount48(1000);
        System.out.println(account.getBalance());
    }
}