public class SavingsAccount48 extends BankAccount48{
    public SavingsAccount48(double balance){
        super(balance);
    }
    public double withdraw(double amount){
        if (super.getBalance() - amount < 0){
            System.out.println("Insufficient funds");
            return super.getBalance();
        }
        else{
            return super.withdraw(amount);
        }
    }
    public static void main(String[] args){
        SavingsAccount48 account = new SavingsAccount48(1000);
        System.out.println(account.getBalance());
        account.withdraw(100.31);
        System.out.println(account.getBalance());
        account.deposit(100.3);
        System.out.println(account.getBalance());
    }
}