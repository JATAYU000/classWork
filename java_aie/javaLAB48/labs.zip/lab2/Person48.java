public class Person48{
    private String name;
    private int phoneNum;
    private String address;
    private String email;
    public Person48(String name, int phoneNum, String address, String email){ 
        this.name = name;
        this.phoneNum = phoneNum;
        this.address = address; 
        this.email = email;
    }
    public String getEmail(){
        return this.email;
    }
    public void setEmail(String email){
        this.email = email;
    }
    public String getAddress(){
        return this.address;
    }
    public void setAddress(String address){
        this.address = address;
    }
    public String getName(){
        return this.name;
    }
    public int getphoneNum(){
        return this.phoneNum;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setphoneNum(int phoneNum){
        this.phoneNum = phoneNum;
    }  
    public String toString(){
        return ("\nName: " + this.name + "\nisFrom Class: Person");
    }
    public static void main(String[] args){
        Person48 p = new Person48("Joe M", 969420024, "Amritapuri, Kollam", "jmama@gmail.com");
        System.out.println(p.toString());}
}