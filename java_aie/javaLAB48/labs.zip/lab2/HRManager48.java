public class HRManager48 extends Employee48{
    public void addEmployee(int salary){
        super(salary);

    }
    public HRManager48(){
        super(10000);
    }
    
    public void work(){
        System.out.println("HRManager specific work");
    }
}