public class StudentPerson48 extends Person48{
    private String batch;
    public StudentPerson48(String name, int phoneNum, String address, String email, String batch){
        super(name, phoneNum, address, email);
        this.batch = batch;
    }
    public String getBatch(){
        return this.batch;
    }
    public void setBatch(String batch){
        this.batch = batch;
    }
    public String toString(){
        return ("Name: " + super.getName() + "\nisFrom Class: StudentPerson");
    }
    public static void main(String[] args){
        StudentPerson48 student = new StudentPerson48("Joe M", 969420024, "Amritapuri, Kollam", "jmama@gmail.com", "2020");
        System.out.println(student.toString());}

}