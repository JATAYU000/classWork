public class PartTimeStaff48 extends StaffEmployee48{
    private int hoursWorked;
    private int hourlySalary;
    public PartTimeStaff48(String name, int phoneNum, String address, String email, int salary, String department, MyDate48
     dateHired, String title, int hourlySalary,int hoursWorked){
        super(name, phoneNum, address, email, hourlySalary*hoursWorked, department, dateHired, title);
    }
    public int getHourlySalary(){
        return this.hourlySalary;
    }
    public void setHourlySalary(int hourlySalary){
        this.hourlySalary = hourlySalary;
    }
    public int getHoursWorked(){
        return this.hoursWorked;
    }
    public void setHoursWorked(int hoursWorked){
        this.hoursWorked = hoursWorked;
    }
    public String toString(){
        return ("Name: " + super.getName() + "\nisFrom Class: PartTimeStaff");
    }
    public static void main(String[] args){
        MyDate48 date = new MyDate48(2019, 1, 1);
        PartTimeStaff48 part = new PartTimeStaff48("Joe M", 969420024, "Amritapuri, Kollam", "jmama@gmail.com", 0, "CSE", date, "Manager", 500, 20);
        System.out.println(part.toString());
    }
}