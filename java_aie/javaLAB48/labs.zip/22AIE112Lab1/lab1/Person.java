public class Person{
	private String name;
	private int age;

	public Person(String name,int age){
		this.name= name;
		this.age = age;
	}
	public Person(){
		this.name = "Default";
		this.age =18;
	}
	void DisplayInfo(){
		System.out.println("Name: " + this.name);
		System.out.println("Age: " + this.age);
	}

	public static void main(String[] args){
		Person p1 = new Person();
		p1.DisplayInfo();
	}
}
