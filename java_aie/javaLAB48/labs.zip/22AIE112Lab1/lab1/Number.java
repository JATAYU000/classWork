public class Number{
	int num;
	Number(int num){
		this.num = num;
	}
	void printNum(){
		System.out.println("The number is : "+this.num);
	}
	
	public static void main(String[] args){
		Number n1 = new Number(10);
		System.out.println("n1.num:"+ n1.num);
		n1.printNum();
	}
}
