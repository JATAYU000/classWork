public class Circlegeo extends Geometry{
    int radius = 1;

Circlegeo(int radius){
    this.radius=radius;
}

    // void setDimension(int radius){
    //     this.radius=radius;
    // }

    // void display(){
    //     System.out.println("Radius: "+this.radius);
    // }

    void getArea(){
        System.out.println("Area: "+this.radius*this.radius*3.14);
    }
    public static void main(String[] args){
        Circlegeo c1 = new Circlegeo(10);
        c1.getArea();
    }
}