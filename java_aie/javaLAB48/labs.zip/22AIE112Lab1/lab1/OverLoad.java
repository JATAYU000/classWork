    public class OverLoad {
       

    static int Sum(int one, int two){
        return one+two;
    }

    static int Sum(int one, int two, int three){
        return one+two+three;
    }

    static double Sum(double onn, double rand){
        return onn+rand;
    }

    static double Sum(double onn, double rand, double moon){
        return onn+rand+moon;
    }

    static float Sum(float ek, float to){
        return ek+to;
    }

    static float Sum(float ek, float to, float theen){
        return ek+to+theen;
    }

    static void Sum(int q, double r){
        System.out.println(q+r);
    }

    static void Sum(double q, int r){
        System.out.println(q+r);
    }

    static void Sum(float c, int d){
        System.out.println(c+d);
    }

    static void Sum(int r, float q){
        System.out.println(q+r);
    }

    static void Sum(float q, double r){
        System.out.println(q+r);
    }

    static void Sum(double q, float r){
        System.out.println(q+r);
    }

    
    

    public static void main(String[] args) {
        System.out.println(Sum(1,2));
        System.out.println(Sum(1, 2,3));
        System.out.println(Sum(1.1,1.2,1.3));
        System.out.println(Sum(1.1,1.2));
        Sum(1.1,49);
        Sum(56,5.9);

        
    }

}
