public class Product {
    private String name;
    private double price;
    private double quantity;

   
    public Product() {
        this.name = "Unknown";
        this.price = 0.0;
        this.quantity = 0.0;
    }

   
    public Product(String name, double price) {
        this.name = name;
        this.price = price;
        this.quantity = 1; 
    }

    public Product(String name, double price, int quantity) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
    }

    public Product(String name, int price) {
        this.name = name;
        this.price = price; 
        this.quantity = 2; 
    }

    public double calculateTotal() {
        return price * quantity;
    }

    public void displayProduct() {
        System.out.println("Product: " + name);
        System.out.printf("Price: "+ price);
        System.out.println("Quantity: " + quantity);
        System.out.printf("Total: "+ calculateTotal());
    }

    public static void main(String[] args) {
        Product product1 = new Product("WaterBottle", 120.0);
        Product product2 = new Product("Pen", 20.0, 5);
        Product product3 = new Product("Eraser", 10);  
        Product product4 = new Product("Scale", 2.0);

        product1.displayProduct();
        product2.displayProduct();
        product3.displayProduct();
        product4.displayProduct();
    }
}
