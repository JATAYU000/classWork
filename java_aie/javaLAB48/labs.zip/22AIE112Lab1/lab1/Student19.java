public class Student19 {

    String firstname;
    String  lastname;
    int age = 18;
    int rollnumber;
    String branch;
    int year;
    String university = "Amrita Vishwa Vidyapeetham";

BStudent(){
    age = 18;
    university = "Amrita Vishwa Vidyapeetham";
}

BStudent(String fn, String ln,int rn, String br, int ye){
    firstname = fn;
    lastname = ln;
    rollnumber = rn;
    branch = br;
    year = ye;
}



BStudent(String fn, String ln, int a, int rn, String br, int ye, String uni){
    firstname = fn;
    lastname = ln;
    age = a;
    rollnumber = rn;
    branch = br;
    year = ye;
    university = uni;
}

public static void main(String[] args) {
    BStudent s1 = new BStudent("Ram", "Shyam",3456, "Maths", 2021);
   System.out.println(s1.age);
    System.out.println(s1.university);
}

}
