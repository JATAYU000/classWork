public class StaffEmployee48 extends EmployeePerson48{
    private String title;
    public StaffEmployee48(String name, int phoneNum, String address, String email, int salary, String department, MyDate48 dateHired, String title){
        super(name, phoneNum, address, email, salary, department, dateHired);
        this.title = title;
    }
    public String getTitle(){
        return this.title;
    }
    public void setTitle(String title){
        this.title = title;
    }
    public String toString(){
        return ("Name: " + super.getName() + "\nisFrom Class: StaffEmployee");
    }
    public static void main(String[] args){
        MyDate48 date = new MyDate48(2019, 1, 1);
        StaffEmployee48 staff = new StaffEmployee48("Joe M", 969420024, "Amritapuri, Kollam", "jmama@gmail.com", 1200000, "CSE", date, "Manager");
        System.out.println(staff.toString());}
}    