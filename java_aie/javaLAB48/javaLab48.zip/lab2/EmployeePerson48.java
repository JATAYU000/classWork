public class EmployeePerson48 extends Person48{
    private int salary;
    private String department;
    private MyDate48 dateHired;
    public EmployeePerson48(String name, int phoneNum, String address, String email, int salary, String department, MyDate48 dateHired){
        super(name, phoneNum, address, email);
        this.salary = salary;
        this.department = department;
        this.dateHired = dateHired;
    }
    public int getSalary(){
        return this.salary;
    }
    public void setSalary(int salary){
        this.salary = salary;
    }
    public String getDepartment(){
        return this.department;
    }
    public void setDepartment(String department){
        this.department = department;
    }
    public MyDate48 getDateHired(){
        return this.dateHired;
    }
    public void setDateHired(MyDate48 dateHired){
        this.dateHired = dateHired;
    }
    public String toString(){
        return ("Name: " + super.getName()  + "\nisFrom Class: EmployeePerson");
    }
    public static void main(String[] args){
        MyDate48 date = new MyDate48(2019, 1, 1);
        EmployeePerson48 emp = new EmployeePerson48("Joe M", 969420024, "Amritapuri, Kollam", "jmama@gmail.com", 1200000, "CSE", date);
        System.out.println(emp.toString());}
}
    