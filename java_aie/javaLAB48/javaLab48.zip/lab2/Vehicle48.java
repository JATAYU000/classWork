public abstract class Vehicle48 {
    
    abstract void StartEngine();
    abstract void StopEngine();


}