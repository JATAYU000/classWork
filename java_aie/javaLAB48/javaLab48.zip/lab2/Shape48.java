public class Shape48{
    public double getArea(){
        return 0;
    }
    public double getPerimeter(){
        return 0.0;
    }
}