public class Current10Account48 extends Bank10Account48 {
    public int minimum_amount = 0;
    public Current10Account48(int account_number, int balance) {
        super(account_number, balance);
    }
    public void deposit(double amount)
     {
        if (balance >= minimum_amount) 
        {
            balance+=amount;
            System.out.println("Current Balance:" + balance + " in " + account_number);
        }
    }
    public void withdraw(double amount) 
    {
        if (balance > minimum_amount) 
        {
            balance-=amount;
            System.out.println(amount + " RUPEES has been withdrawn from " + account_number);
        }
    }
    public static void main(String args[])
    {
        Current10Account48 account=new Current10Account48(11223344, 56);
        account.deposit(690);
        account.withdraw(110);
        account.getaccount_number();
        account.setaccount_number(12121212);
        account.setbalance(15478);

        Saving10Account48 account1=new Saving10Account48(44332211, 90);
        account1.deposit(45);
        account1.withdraw(275);
        account1.getaccount_number();
        account.setaccount_number(21212121);
        account1.setbalance(1);

    }
}
