public class Square48 extends Shape48{
    private int side;
    public Square48(int side){
        this.side = side;
    }
    public double getArea(){
        return side * side;
    }
    public static void main(String[] args){
        Square48 square = new Square48(15);
        System.out.println(square.getArea());
    }
}