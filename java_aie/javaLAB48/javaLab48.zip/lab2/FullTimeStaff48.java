public class FullTimeStaff48 extends StaffEmployee48{
    private int fixedSalary;
    public FullTimeStaff48(String name, int phoneNum, String address, String email, int salary, String department, MyDate48 dateHired, String title, int fixedSalary){
        super(name, phoneNum, address, email, fixedSalary, department, dateHired, title);
    }
    public int getFixedSalary(){
        return this.fixedSalary;
    }
    public void setFixedSalary(int fixedSalary){
        this.fixedSalary = fixedSalary;
    }   
    public String toString(){
        return ("Name: " + super.getName() + "\nisFrom Class: FullTimeStaff");
    }
    public static void main(String[] args){
        MyDate48 date = new MyDate48(2019, 1, 1);
        FullTimeStaff48 full = new FullTimeStaff48("Joe M", 969420024, "Amritapuri, Kollam", "jmama@gmail.com", 0, "CSE", date, "Assistant", 50000);
        System.out.println(full.toString());}
}