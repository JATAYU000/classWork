public abstract class Bank10Account48 {
    int account_number;
    int balance;
    public Bank10Account48(int account_number, int balance) {
        this.account_number = account_number;
        this.balance = balance;
    }
    public int getaccount_number() {
        return account_number;
    }
    public void setaccount_number(int account_number) {
        this.account_number = account_number;
        System.out.println(account_number);
    }
    public int getbalance() {
        return balance;
    }
    public void setbalance(int balance) {
        this.balance = balance;
        System.out.println(balance);
    }
    public abstract void deposit(double amount);
    public abstract void withdraw(double amount);
}
