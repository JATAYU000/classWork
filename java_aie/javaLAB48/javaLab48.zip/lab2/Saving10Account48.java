public class Saving10Account48 extends Bank10Account48 {
    private double minimum_balance = 200;
    public Saving10Account48(int account_number, int balance) {
        super(account_number, balance);
    }
    public void deposit(double amount) {
        balance += amount;
        System.out.println("Curretn Balance: " + balance + " in ACCOUNT: " + account_number);
    }
    public void withdraw(double amount) {
        if (balance - amount >= minimum_balance) {
            balance -= amount;
            System.out.println(amount + " RUPEES has been withdrawn from " + account_number + " \nBALANCE IS : " + balance);
        } else {
            System.out.println("INSUFFICIENT Balance!!");
        }
    }
}

