public class Car48 extends Vehicle48 {

    public void StartEngine(){
        System.out.println("Car started");
    }
    public void StopEngine(){
        System.out.println("Engine Off");
    }

    public static void main(String[] args){
        Car48 c1=new Car48();
        c1.StartEngine();
        c1.StopEngine();
    }
    
}
