public class Motorcycle48 extends Vehicle48 {

    public void StartEngine(){
        System.out.println("Engine Started");
    }
    public void StopEngine(){
        System.out.println("Engine Off");
    }
    public static void main(String[] args) {
        Motorcycle48 bike=new Motorcycle48();
        bike.StartEngine();
        bike.StopEngine();
        
    }
    
}
